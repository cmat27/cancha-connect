import { createTeamService } from '../services/teamService.js';
import { formatResponse, formatError } from '../utils/responseFormatter.js';

/**
 * AWS Lambda Handler: POST /teams
 * * @param {Object} event - The API Gateway HTTP API v2 event object.
 * @returns {Object} API Gateway formatted HTTP response.
 */
export const handler = async (event) => {
  // 1. Log the incoming event.
  // Using console.info/error automatically writes structured logs to AWS CloudWatch.
  console.info(
    'Received event to create team:',
    JSON.stringify(event.routeKey),
  );

  try {
    // 2. Validate that a body was actually provided in the HTTP POST request
    if (!event.body) {
      return formatError(
        400,
        'Missing request body. Please provide team details.',
      );
    }

    // 3. Safely parse the JSON payload
    let payload;
    try {
      // API Gateway sometimes base64-encodes the body depending on headers,
      // but standard HTTP APIs with JSON usually pass it as a raw string.
      const bodyString = event.isBase64Encoded
        ? Buffer.from(event.body, 'base64').toString('utf-8')
        : event.body;
      payload = JSON.parse(bodyString);
    } catch (parseError) {
      console.error('JSON Parsing Error:', parseError);
      return formatError(400, 'Invalid JSON format in the request body.');
    }

    // 4. Pass the parsed data to the Service Layer (Business Logic)
    const createdTeam = await createTeamService(payload);

    // 5. Return a successful HTTP 201 (Created) response
    return formatResponse(201, {
      message: 'Team successfully registered!',
      team: createdTeam,
    });
  } catch (error) {
    console.error('Error creating team:', error);

    // 6. Graceful Error Handling
    // If our service layer throws a specific validation error, tell the client.
    if (
      error.name === 'ValidationError' ||
      error.message.includes('Validation')
    ) {
      return formatError(400, error.message);
    }

    if (error.name === 'ConditionalCheckFailedException') {
      // Return a friendly 409 Conflict or 400 Bad Request
      return formatError(409, 'A team with this ID already exists.');
    }

    // For all other unexpected errors (like DynamoDB going down), return a generic 500.
    // Never leak raw stack traces to the public API!
    return formatError(
      500,
      'An internal server error occurred while creating the team.',
    );
  }
};
